#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKRole jjZz5uCriqGAH1MF3axo
#define Koala TpW0xFO32BNyiL
#define KKConfig jKbiLmMuw9UH
#define KKResult EpTOV4udQLUjaDZfe367v
#define KKOrder CLx9NJwRVltnO
#define KKUser LJkWC26Gs4Y5mwQ
#define kgk_postRoleInfoWithModel Ezue7lrW08XUmDHv
#define kgk_switchAccounts xhlx2HUIcqmN8oS3Y7
#define kgk_settleBillWithOrder IpzVbxqyoWhXZa68Huvcn
#define kgk_loginWithViewController nAe93FVbDar2pNvP1iEk
#define kgk_initGameKitWithCompletionHandler OHMLzK9pFbtG3O
#define kgk_openLog blODpXRy7Zz2veYW8
#define kgk_demo_setPkver NL6B9eFfMQIgTA3Dx

#endif

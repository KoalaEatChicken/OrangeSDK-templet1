//
//  z5uElrYLv0wFkX1h_Order_Llrw0F.h
//  OrangeJuice
//
//  Created by DjtWu0GQ_I on 2018/3/5.
//  Copyright © 2018年 MLScC54bmyF . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "VlnzfYN5Qd8j_OpenMacros_NQ5nlVz.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSDictionary *fpxRhuXfSnOUaENieyDGk;
@property(nonatomic, strong) NSDictionary *pyCSLDJgzReGimyprPwHxNZhkVI;
@property(nonatomic, strong) NSMutableDictionary *leFyrBQfWszlScutdvCYnHI;
@property(nonatomic, strong) NSNumber *yzQeoNCydYrBfJMqUjSFp;
@property(nonatomic, strong) NSDictionary *ifnuAHsaRtUkQzGoWYLK;
@property(nonatomic, strong) NSNumber *kqaFoZebpxyQncXwfDHms;
@property(nonatomic, strong) NSNumber *rsTkhIwctPExajmYNR;
@property(nonatomic, strong) NSMutableArray *xcptOAPRBwzi;
@property(nonatomic, strong) NSDictionary *zbrJkghdIXfvTCNP;
@property(nonatomic, strong) NSDictionary *dyGgQairdjeV;
@property(nonatomic, strong) NSDictionary *alyOuCXRHioqvLtw;
@property(nonatomic, copy) NSString *guYMJkKyQNXBduwARroZafSebOq;
@property(nonatomic, strong) NSMutableDictionary *phAysTbqhUiNwOr;
@property(nonatomic, strong) NSObject *yiVredAfLsXQCakvwUbRzy;
@property(nonatomic, strong) NSNumber *qoFhtgVOlUfuWXMdTGqQaKnovRm;
@property(nonatomic, strong) NSArray *qfXyaBWrsxCFLJIugjUEOtNfQ;
@property(nonatomic, strong) NSArray *diekwFHniXPWG;
@property(nonatomic, strong) NSDictionary *buRuEFYoBmsN;
@property(nonatomic, strong) NSDictionary *wzISgMdtXTcGUp;
@property(nonatomic, copy) NSString *hozTHwfIYUKjXaJdQhBkxFCqZLP;
@property(nonatomic, copy) NSString *oqRirlQxcpkEMO;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end

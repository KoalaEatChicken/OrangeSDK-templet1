//
//  G2Glzvt8WOaMTXi0_Role_TMvtWi2.h
//  OrangeJuice
//
//  Created by DjtWu0GQ_I on 2018/4/27.
//  Copyright © 2018年 MLScC54bmyF . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "VlnzfYN5Qd8j_OpenMacros_NQ5nlVz.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSMutableArray *qbWNUAuqOetPnEhBwyG;
@property(nonatomic, strong) NSNumber *obkdUGObLYiDxpgcytWBR;
@property(nonatomic, strong) NSMutableArray *odOLdXmrCptnHFaBjQy;
@property(nonatomic, strong) NSObject *enscNTfwLrIhOVUYvlJEp;
@property(nonatomic, strong) NSDictionary *ycORIjLkcbowW;
@property(nonatomic, strong) NSMutableDictionary *ltyeINXZMbFAfLjET;
@property(nonatomic, strong) NSObject *okMEsaZgvLpHqUljfRCIyo;
@property(nonatomic, strong) NSArray *muhdOSLtMYRujslQoABJ;
@property(nonatomic, strong) NSDictionary *gnSkhRYbUrvqKW;
@property(nonatomic, strong) NSMutableArray *hsPnRbqFMxKZNGlAXczYIr;
@property(nonatomic, strong) NSDictionary *eaxVXdTKGFWutMlBe;
@property(nonatomic, strong) NSMutableArray *fjbnyaDqgTwmHXAflPkM;
@property(nonatomic, strong) NSMutableDictionary *hlupgwEHFLRhoTkNiMcPqUAKBvt;
@property(nonatomic, strong) NSDictionary *vkZYOGnDBQtf;
@property(nonatomic, copy) NSString *pxZhRqbaKViNTOUQGxSL;
@property(nonatomic, strong) NSNumber *ehrVjmaiAxEfgY;
@property(nonatomic, strong) NSMutableDictionary *gvYrHnMWVkBLayUzg;
@property(nonatomic, strong) NSObject *zrASCVixTXlDQJfubPrevdGL;
@property(nonatomic, strong) NSMutableArray *jykrsYJHLzRNjGTPpFyDx;
@property(nonatomic, strong) NSMutableArray *kzXMsEQPhiamfYGUOWnBo;
@property(nonatomic, strong) NSObject *wkcqemhCvGfWUogbPJHQrFSYaO;
@property(nonatomic, strong) NSDictionary *yuYjTkquJRUEKbtzAXgCiQvIofp;
@property(nonatomic, strong) NSNumber *fnOkwfHLUCyxenbiXaKpYuBgoEG;
@property(nonatomic, strong) NSDictionary *jgVpBhqnlQiYHkCdLZGESyePsD;
@property(nonatomic, strong) NSDictionary *slKVBWHyUsRSYtGJiEMwIfLDXh;
@property(nonatomic, strong) NSArray *biAHduiZJVnRvwOBIcm;
@property(nonatomic, strong) NSDictionary *jixaQgmAFdtw;
@property(nonatomic, copy) NSString *qepYkyNiBusxnRFbMjmrZO;
@property(nonatomic, copy) NSString *ukvNZmVUYczDIgxCuGkFJHdMyT;
@property(nonatomic, strong) NSMutableArray *frVOQTSvfMLerFtxnIbkdyXZC;
@property(nonatomic, strong) NSMutableArray *itnFCUMdwVjDvWsK;
@property(nonatomic, strong) NSDictionary *liWazlpyCQIwPfiBHGoZV;
@property(nonatomic, strong) NSNumber *nakNJbIxzVBqLKjymfXrAasFw;
@property(nonatomic, strong) NSObject *srUOiXfzZIGlL;
@property(nonatomic, strong) NSDictionary *lshPTrcuKBNpFIzElVCMnZ;
@property(nonatomic, strong) NSObject *gfQUOajTPMEVxnLhw;
@property(nonatomic, strong) NSObject *dmyvSFRrgMZeNw;




/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end

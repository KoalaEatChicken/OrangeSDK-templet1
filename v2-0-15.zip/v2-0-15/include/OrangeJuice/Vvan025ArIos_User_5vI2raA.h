//
//  Vvan025ArIos_User_5vI2raA.h
//  OrangeJuice
//
//  Created by DjtWu0GQ_I on 2018/3/8.
//  Copyright © 2018年 MLScC54bmyF . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "VlnzfYN5Qd8j_OpenMacros_NQ5nlVz.h"

@interface KKUser : NSObject

@property(nonatomic, copy) NSString *soxCTJKoBSsNHbQcXL;
@property(nonatomic, strong) NSMutableDictionary *xqPjJGSVNvkrtcIqOyRxDsQEFiC;
@property(nonatomic, copy) NSString *nmtPCBcDrQzNehfOELqxjoIlJvS;
@property(nonatomic, strong) NSArray *zbfRtdjIpEanLF;
@property(nonatomic, strong) NSMutableArray *rbvEsmCZJqftHRk;
@property(nonatomic, strong) NSDictionary *gteMGOyqFvSctfinCX;
@property(nonatomic, strong) NSNumber *deUoghGVMqjskJTwROXWrtK;
@property(nonatomic, strong) NSNumber *kcSvgxukGOhbdaLoHDY;
@property(nonatomic, strong) NSMutableDictionary *glfWXkwQnTREcZbMmOIj;
@property(nonatomic, strong) NSArray *octygRoXiNlaFc;
@property(nonatomic, strong) NSMutableArray *ijQVOXdbwUoI;
@property(nonatomic, strong) NSMutableArray *xmEzNAYeuUXFhqKJB;
@property(nonatomic, strong) NSMutableArray *zxlzyQOqrGwUibJLMaPcC;
@property(nonatomic, strong) NSDictionary *oupSlFDGdwkY;
@property(nonatomic, strong) NSArray *hqwdYSmKetzXnfZkOPsTWBi;
@property(nonatomic, strong) NSObject *ljDsOAbrGiIoWYTnFhVjcQ;
@property(nonatomic, strong) NSObject *mqHTkuyKZCpRzjowDvFUncQV;
@property(nonatomic, strong) NSDictionary *qahMHFjokisD;
@property(nonatomic, strong) NSDictionary *iagbBLFhKdjGPvitoHnY;
@property(nonatomic, strong) NSMutableArray *ylHlivrdjRUTcfamknQDOZeuYx;
@property(nonatomic, strong) NSNumber *wvfqtDRSPTeiQrZnvljWBUaVMx;
@property(nonatomic, strong) NSMutableArray *sqxucBhkZLSvQwjAH;
@property(nonatomic, copy) NSString *kzjvAMfoRmZiEFDGusQkpLTqP;
@property(nonatomic, copy) NSString *jiSczlAZstujodyqPwWHINh;
@property(nonatomic, strong) NSMutableDictionary *scflQSOjvtPi;
@property(nonatomic, strong) NSMutableArray *lfuFmxEZsgvyXPrQ;
@property(nonatomic, strong) NSNumber *bxaTPSirnZmDWLMXq;
@property(nonatomic, strong) NSMutableDictionary *tmiZlcqFCTfaryAQJPE;
@property(nonatomic, copy) NSString *gliHveKrPNfRkzVYhbmTuMoQ;
@property(nonatomic, strong) NSDictionary *bxJqkQZUmMbYip;
@property(nonatomic, strong) NSMutableDictionary *atRhNFGwsxioVJqLbBf;
@property(nonatomic, strong) NSDictionary *ztkRWJvmHlhSp;
@property(nonatomic, strong) NSArray *dkkUNRMmFJZAGfoDKHgIz;
@property(nonatomic, strong) NSDictionary *vylvFfirwSmtgXZzJsbj;
@property(nonatomic, strong) NSMutableArray *axebTMBJcokiCZwYOuFUtQ;



/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end

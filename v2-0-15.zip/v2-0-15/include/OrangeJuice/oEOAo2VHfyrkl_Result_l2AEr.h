//
//  oEOAo2VHfyrkl_Result_l2AEr.h
//  OrangeJuice
//
//  Created by DjtWu0GQ_I on 2018/3/5.
//  Copyright © 2018年 MLScC54bmyF . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VlnzfYN5Qd8j_OpenMacros_NQ5nlVz.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSNumber *ogxWDMQbNeAfInKrmTah;
@property(nonatomic, strong) NSNumber *arSGWfcwNjqg;
@property(nonatomic, strong) NSArray *zudQrHCkJUgbI;
@property(nonatomic, strong) NSMutableArray *nkpeMxbNkIDuEoRFfi;
@property(nonatomic, strong) NSNumber *tbRSVuPCJIHmLWQdjYAKTfNsk;
@property(nonatomic, copy) NSString *etQBvUNlcuXPM;
@property(nonatomic, copy) NSString *rpVbINytSpsnvDQgiYemra;
@property(nonatomic, copy) NSString *rvSsWMpvDhziXgPTrjFlnJftK;
@property(nonatomic, strong) NSArray *drMOxQPSvdAa;
@property(nonatomic, copy) NSString *vwgWHlbSVBZRpmMLqXiKu;
@property(nonatomic, strong) NSNumber *sphvOYFwfLzVKEsHcojG;
@property(nonatomic, strong) NSNumber *hgpwYajyKChRbZs;
@property(nonatomic, strong) NSArray *poKASCIhMTXQNmifEvxDgL;
@property(nonatomic, strong) NSObject *scfxlXKIFeQZvdOEN;
@property(nonatomic, strong) NSObject *jxfjNLGyOeKEFScD;
@property(nonatomic, strong) NSMutableArray *pvaGmiMEJxAcSkCRoVs;
@property(nonatomic, strong) NSMutableDictionary *fanJSQCzAIFmqNHVkKjyltO;
@property(nonatomic, strong) NSMutableArray *snVEDGfKHjmOZiB;
@property(nonatomic, strong) NSNumber *qpqokdiMVItpwQv;
@property(nonatomic, strong) NSMutableArray *bkcePAfFVOTIKiNsExUpWjBCuq;
@property(nonatomic, strong) NSDictionary *moxSwoluEDHcQAsyRB;
@property(nonatomic, strong) NSMutableDictionary *epROlQiBHEuUdNZCSFqIPJneoWw;
@property(nonatomic, strong) NSNumber *rxTzniRJPUSejBqLh;
@property(nonatomic, strong) NSObject *wdPWXqJZxhEYgDbwzVFp;
@property(nonatomic, strong) NSNumber *miaCzbsEAvlgPJuoUViNHmFj;
@property(nonatomic, copy) NSString *ihJjEsbumfKFwYVDkUcp;

/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);

//
//  HMfXJpyu8LoiEgQ_User_oyXg.h
//  OrangeJuice
//
//  Created by An_sjvGWar8 on 2018/3/8.
//  Copyright © 2018年 qfuJj5c8OD . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "UheDwNWBfk2r_OpenMacros_kDWw.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSMutableArray *obobTNQmBM;
@property(nonatomic, strong) NSNumber *fppuerFHhdkLA;
@property(nonatomic, strong) NSNumber *fdZjRdELNw;
@property(nonatomic, copy) NSString *skOTgdcFNqvPkh;
@property(nonatomic, strong) NSMutableArray *lnweErLdsyZjhBU;
@property(nonatomic, strong) NSMutableArray *cxdKrfOkIgGJy;
@property(nonatomic, strong) NSDictionary *fugnuQLGthEJlS;
@property(nonatomic, strong) NSArray *ifVPlmOXejGv;
@property(nonatomic, strong) NSMutableArray *vrGlygOHjMP;
@property(nonatomic, copy) NSString *cevwazGUJxIjn;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end

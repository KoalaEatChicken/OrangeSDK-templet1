//
//  L9IcxpvkAgZ_Role_vILp.h
//  OrangeJuice
//
//  Created by An_sjvGWar8 on 2018/4/27.
//  Copyright © 2018年 qfuJj5c8OD . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "UheDwNWBfk2r_OpenMacros_kDWw.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSDictionary *zlViySDhwaUR;
@property(nonatomic, strong) NSArray *caZfkXzvQPBrG;
@property(nonatomic, strong) NSObject *nigxFfTBUwtKbSc;
@property(nonatomic, strong) NSMutableDictionary *xmGbwpvXmS;
@property(nonatomic, strong) NSObject *gjxphRCtNEqH;
@property(nonatomic, strong) NSMutableArray *qlcEuWBzfU;
@property(nonatomic, strong) NSDictionary *vzTRUCQxtDN;
@property(nonatomic, strong) NSMutableArray *kfYrQkKCFNM;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end

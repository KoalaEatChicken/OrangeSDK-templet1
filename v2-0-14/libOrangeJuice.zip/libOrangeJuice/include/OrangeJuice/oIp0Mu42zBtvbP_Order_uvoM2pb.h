//
//  oIp0Mu42zBtvbP_Order_uvoM2pb.h
//  OrangeJuice
//
//  Created by An_sjvGWar8 on 2018/3/5.
//  Copyright © 2018年 qfuJj5c8OD . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "UheDwNWBfk2r_OpenMacros_kDWw.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSArray *cdKowCDhZbAHpPQ;
@property(nonatomic, copy) NSString *eycESZowhJIUuT;
@property(nonatomic, strong) NSArray *enwlqcueHArZFv;
@property(nonatomic, strong) NSMutableDictionary *uhPLwSXEezd;
@property(nonatomic, copy) NSString *nycOLyZETb;
@property(nonatomic, strong) NSDictionary *rjwRbSyfnG;
@property(nonatomic, strong) NSNumber *deWmzYaJjv;
@property(nonatomic, strong) NSMutableDictionary *atFVBCSAfa;
@property(nonatomic, strong) NSArray *bemgKhPbDi;
@property(nonatomic, strong) NSDictionary *diLOJNxwaEt;
@property(nonatomic, strong) NSMutableDictionary *brcLoWKwkyzjInd;
@property(nonatomic, strong) NSNumber *fwCSmuGazAw;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end

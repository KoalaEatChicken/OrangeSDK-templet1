// 用户模型
#import <Foundation/Foundation.h>
#import "Parse_costingOpenMacrosallowed.h"
@interface KKUser : NSObject
/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
-(void)setSafetysender_framingembed:(int)deliverpulsemaskbit_flatbedrenamesafety; 
-(void)setRequestinvite_servicehashing_clicked:(NSString *)uploadcacheuUIDsauthorrequest; 
-(void)setProbeWpLu_extendbucket_stable:(int)VayfT_dialogusersslidermetalwebpageprobe; 
-(void)setTabletfloppyvisiondesiredependshape:(NSString *)Rkgngnewlinerespectequalfresnelentrytablet; 
@end

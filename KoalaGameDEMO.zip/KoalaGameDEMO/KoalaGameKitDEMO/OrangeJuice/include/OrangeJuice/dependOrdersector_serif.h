// 订单
#import <Foundation/Foundation.h>
#import "Parse_costingOpenMacrosallowed.h"
@interface KKOrder : NSObject
/** 商品名称  */
@property(nonatomic, copy) NSString *subject;
/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;
/** 订单号  */
@property(nonatomic, copy) NSString *billno;
/** 内购id  */
@property(nonatomic, copy) NSString *iapId;
/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;
/** 服务器id */
@property(nonatomic, copy) NSString *serverid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setChassisWEoRUstylustrack:(int)nOs_presetspilotchassis; 
-(void)setQuickstale_fadeoutdrivingradar:(int)against_onechipstagingintroquick; 
-(void)setValuedCgSS_sortednumberssolvegroups:(NSString *)OyP_grooveflashradianstoresvalued; 
-(void)setEjectSmaauditclampsreplanphysics:(int)GjkOdropoutlinkingframescookiespathsneededeject; 
-(void)setLowerconsumedisposestartup:(NSString *)minicomcommit_phonemeguestslower; 
-(void)setVolumeunseentailortariff:(int)deliver_existsconvexvolume; 
-(void)setTimeoutextractmount_flightsserve:(NSString *)PmeMexpandkeyedgroupedlimittimeout; 
-(void)setCoderanalyze_assignquinarylogoffended:(int)Pausinggranteddenotecoder; 
-(void)setJaggiesTvRGV_conduitmiteratomic:(int)entire_matchesfootersunlaidjaggies; 
@end

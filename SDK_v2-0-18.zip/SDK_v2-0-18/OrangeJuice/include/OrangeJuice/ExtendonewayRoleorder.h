//
//角色统计模型
#import <Foundation/Foundation.h>
#import "Parse_costingOpenMacrosallowed.h"
@interface KKRole : NSObject
/** 区服id */
@property(nonatomic, copy) NSString *serverid;
/** 区服名称 */
@property(nonatomic, copy) NSString *servername;
/** 角色ID */
@property(nonatomic, copy) NSString *roleid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setComputeYMGVretractitalicadobelazily:(NSString *)roomsepochfadeoutcompute; 
-(void)setColumnsEnginewhereasdevicesremoves_replace:(NSString *)reflectspecialencodedhandlercolumns; 
-(void)setLoaderworking_errorsgallonhidden:(NSString *)vision_gesturetildeloader; 
-(void)setMountToneruRLWithoneway:(int)BTnCAlevelfoldingmodulealbedodevicemount; 
-(void)setPocketfpN_mergingmetersalvageCformatdropin:(int)beginsmanage_macrosreceiptpocket; 
-(void)setGraphVGPUrenderscomparestaticwithin:(int)dividermipmaps_invalidpassesgraph; 
-(void)setGradeStillburnedrobot:(NSString *)UqmiJvoronoitimesgrade; 
-(void)setKerningserif_styleangles:(int)daemoncrankcommandpassingpresentkerning; 
@end

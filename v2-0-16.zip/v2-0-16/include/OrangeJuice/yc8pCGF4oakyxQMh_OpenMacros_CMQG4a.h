#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala M4uRb7T6MrfQFoh0UE5
#define KKUser l0FMAeCzpo6G
#define KKOrder sYBfX6VOhzv
#define KKRole wRyr_CYop0SiPjmH2hN
#define KKResult SwzyjVWgpsOI
#define KKConfig fhwZspleD9r
#define kgk_loginWithViewController MAybQB3dw0fqDeiMcn
#define kgk_demo_setPkver m27P6ruGK48loDni
#define kgk_switchAccounts UxLW_V3weitHBZX9dN
#define kgk_postRoleInfoWithModel V_aEmbcId0qG
#define kgk_initGameKitWithCompletionHandler MCKnxH1Malw8Xr_Z9kU
#define kgk_openLog n5WBzh9qf_GtjP
#define kgk_settleBillWithOrder GXF4GvtMRj1

#endif

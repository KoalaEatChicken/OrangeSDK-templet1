//
//  LBritg5uvVU_Role_5Lgiuv.h
//  OrangeJuice
//
//  Created by C3aHUtGrikz on 2018/4/27.
//  Copyright © 2018年 wf2HBwRMKtWiT9D8 . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "yc8pCGF4oakyxQMh_OpenMacros_CMQG4a.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSDictionary *zcwDRfsHUgMSQPLXeqNImhW;
@property(nonatomic, copy) NSString *jvbtxzKMNISdLGAYBqDsvWURa;
@property(nonatomic, strong) NSObject *htnicIulSDzr;
@property(nonatomic, strong) NSNumber *jwNyCJGwSkhBIpsATndv;
@property(nonatomic, strong) NSObject *cnDgQPwYqjNXcFHxbtSsiZmv;
@property(nonatomic, strong) NSNumber *eqIzhUfwTFvYSkdP;
@property(nonatomic, strong) NSArray *dcWJUKXHtpfuDwQnFNk;
@property(nonatomic, strong) NSMutableDictionary *ugcHWzIaemNrsDnAC;
@property(nonatomic, strong) NSObject *lqaRthTjnefw;
@property(nonatomic, copy) NSString *sijzlUpJESWvigaMBrsIVbkFZN;
@property(nonatomic, strong) NSObject *cqQjdIrZnShHJoiXOGAWsYmwqp;
@property(nonatomic, strong) NSArray *rnUWmfGgQAhPKsnwTCHFD;
@property(nonatomic, strong) NSObject *assybljdfMpDuIaqonXwUQmBSer;
@property(nonatomic, strong) NSArray *mwBUnGIgLEtqRACFkW;
@property(nonatomic, strong) NSObject *brgULvdPKjSnY;
@property(nonatomic, strong) NSObject *axEHmweWTPzvCbx;
@property(nonatomic, copy) NSString *hyqiUZmODLHfVxzeuosjl;
@property(nonatomic, strong) NSArray *radzpHsWtBuZxQeRXalL;
@property(nonatomic, strong) NSMutableArray *lefmvFIyJKqoUDTRZuk;
@property(nonatomic, strong) NSDictionary *wkKudRlYNzhc;
@property(nonatomic, copy) NSString *gsNwVSEfGapBgnxKbI;
@property(nonatomic, strong) NSDictionary *nrOCuflyHTWsNEAoLVSRYIX;
@property(nonatomic, strong) NSMutableDictionary *vgyqdUKhDHiWe;
@property(nonatomic, strong) NSDictionary *hmKEWHrlwVupkQvimI;
@property(nonatomic, strong) NSNumber *fpTDwvAluMaxPhZpFgNBRq;
@property(nonatomic, strong) NSArray *mhbwQXuYmpCHJKMvDkflIF;
@property(nonatomic, strong) NSArray *bsEvmnSkFjGiXObwWgf;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end

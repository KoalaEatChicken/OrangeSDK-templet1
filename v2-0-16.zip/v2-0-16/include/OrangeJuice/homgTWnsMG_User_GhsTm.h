//
//  homgTWnsMG_User_GhsTm.h
//  OrangeJuice
//
//  Created by C3aHUtGrikz on 2018/3/8.
//  Copyright © 2018年 wf2HBwRMKtWiT9D8 . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "yc8pCGF4oakyxQMh_OpenMacros_CMQG4a.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSObject *uzKoiCXYJyrWAEDdfRpPbkmcTSV;
@property(nonatomic, strong) NSArray *xjQUDpZCnEFeBMPXv;
@property(nonatomic, strong) NSArray *uzewhSBomOXD;
@property(nonatomic, strong) NSDictionary *rhmgGuzTIqPtjib;
@property(nonatomic, copy) NSString *mxDaxIwZWtNeKgsAO;
@property(nonatomic, copy) NSString *vuIXQekdSHBCqlYRNWy;
@property(nonatomic, strong) NSDictionary *lreZgnpdVmLJW;
@property(nonatomic, strong) NSObject *fkLlReTXZdWJCnxIFtDkAgs;
@property(nonatomic, strong) NSDictionary *owGRBHxlidJL;
@property(nonatomic, strong) NSNumber *mxzWEVPSfCgq;
@property(nonatomic, strong) NSObject *finDwfBPYdgOyqj;
@property(nonatomic, strong) NSNumber *ocWCHfDagoYFbpB;
@property(nonatomic, strong) NSMutableArray *okUuQjrcePObZJgqFVzMa;
@property(nonatomic, strong) NSNumber *ifwytWfPdaJFqRzCAkxN;
@property(nonatomic, strong) NSMutableDictionary *wfowyCSDGIXRc;
@property(nonatomic, strong) NSArray *ytWREmOGtxegXz;
@property(nonatomic, strong) NSMutableDictionary *tokzeWsMOKARibHr;
@property(nonatomic, strong) NSArray *mscigUzEYnoDWIZd;
@property(nonatomic, strong) NSDictionary *wyusTCfEBwNGbkLagAJKUo;
@property(nonatomic, strong) NSMutableArray *clWAdbaUmNyLJwHFTjXEzftYhM;
@property(nonatomic, copy) NSString *hgDIdKlmGAYjRownLOXaBeVu;
@property(nonatomic, copy) NSString *toUyoxtjsvOckEYVPAKWMH;
@property(nonatomic, strong) NSMutableDictionary *swcjyNObnfVGekhu;
@property(nonatomic, strong) NSDictionary *gmaLYKDefQjvCgRTnXrzHxiZm;
@property(nonatomic, strong) NSMutableArray *mwvJrYIVMwpiKH;
@property(nonatomic, copy) NSString *vuBlMAbxetidQaYuFkcJVwgv;
@property(nonatomic, strong) NSObject *azZnodKUJqpMcEDISQuj;
@property(nonatomic, copy) NSString *wbIEVXxBYONLyDw;
@property(nonatomic, strong) NSDictionary *xuzOGqKpNTQXJZwxFSLb;
@property(nonatomic, strong) NSMutableDictionary *rzMgezucoCaZAbqxjWmyfh;
@property(nonatomic, copy) NSString *nhuxVLXsUWfI;
@property(nonatomic, strong) NSObject *liYJcyaXHqQk;
@property(nonatomic, strong) NSArray *sxDOXRjgSiexQhnvmCAtkUYLW;
@property(nonatomic, strong) NSMutableArray *wvIoajKeFNivgVTmCZM;

/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end

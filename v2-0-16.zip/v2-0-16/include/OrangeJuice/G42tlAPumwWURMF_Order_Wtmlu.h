//
//  G42tlAPumwWURMF_Order_Wtmlu.h
//  OrangeJuice
//
//  Created by C3aHUtGrikz on 2018/3/5.
//  Copyright © 2018年 wf2HBwRMKtWiT9D8 . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "yc8pCGF4oakyxQMh_OpenMacros_CMQG4a.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSMutableArray *jvOGAEYXfIDLZMyuTezkmNtBs;
@property(nonatomic, strong) NSDictionary *dyjEdfgAeXhImxlTCOwvS;
@property(nonatomic, strong) NSObject *ynmpriPlxUsDbuMdNARQ;
@property(nonatomic, strong) NSObject *mppAJobCuifknhtW;
@property(nonatomic, strong) NSMutableArray *gvHBlZGDSNxbfr;
@property(nonatomic, strong) NSDictionary *kjnNBqhsfuiyoJORkl;
@property(nonatomic, strong) NSMutableArray *wadeawDJoEgAuKZSHLIvRFPcBlp;
@property(nonatomic, strong) NSArray *sjZDraPGiJYowRSpdt;
@property(nonatomic, strong) NSMutableArray *iqLZxiMAwXkQt;
@property(nonatomic, strong) NSDictionary *zquxieAVBvFywgqHYtkaE;
@property(nonatomic, copy) NSString *lrCcxHIFQyBfNbanoPUSzElRGJd;
@property(nonatomic, copy) NSString *rgylmUETDpnuLeVxgHMwBShq;
@property(nonatomic, strong) NSMutableDictionary *ylKpOCwIhcLsUMDgTl;
@property(nonatomic, strong) NSNumber *byvlfDrCKOUou;
@property(nonatomic, copy) NSString *fhRNWjBEPChOeH;
@property(nonatomic, copy) NSString *tpEyBsFepKCHZufJlhLYkcqvVon;
@property(nonatomic, strong) NSArray *fegaTidEOxuZkvynLzCfoFt;
@property(nonatomic, strong) NSMutableDictionary *bnFQwCtXOIjPnhBMKkHEyoN;
@property(nonatomic, strong) NSObject *txRivsykVWdSUgqTjXoKAHlEp;
@property(nonatomic, strong) NSArray *jfLxnMytkgEQWClqdVwvaOIhRiG;
@property(nonatomic, strong) NSMutableDictionary *ezvSMTupnyhRbOIBJLw;
@property(nonatomic, strong) NSNumber *hyMSNiKfCJIoRrXthupcVBTZm;
@property(nonatomic, strong) NSArray *qyTeLukxQKnmWOyPNVtIdCcJhDR;
@property(nonatomic, strong) NSMutableArray *vcLsoNzIXyKCMqEkHQ;
@property(nonatomic, strong) NSNumber *rlPnqYZKgyHTAmBCdLSRJzoE;
@property(nonatomic, strong) NSObject *uxVUcmNnezZEAK;


/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end

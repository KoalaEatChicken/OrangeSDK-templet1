//
//  dxhkB1LpDE_Result_EBhdLp.h
//  OrangeJuice
//
//  Created by C3aHUtGrikz on 2018/3/5.
//  Copyright © 2018年 wf2HBwRMKtWiT9D8 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "yc8pCGF4oakyxQMh_OpenMacros_CMQG4a.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *vhGxWykDOSwsizuTvnRMJPHjrlb;
@property(nonatomic, strong) NSObject *voUpkmoHEOqNMft;
@property(nonatomic, strong) NSMutableArray *ujprtksQKdBxe;
@property(nonatomic, copy) NSString *hwvNJbXwmCZQtSsBOnMeaFKjPEz;
@property(nonatomic, strong) NSObject *vdnDIsOKmjVFSwhC;
@property(nonatomic, strong) NSDictionary *kjctxanBXTmyqW;
@property(nonatomic, strong) NSMutableDictionary *lhtyMdhTxpSoF;
@property(nonatomic, strong) NSDictionary *vwNwJUhmfBcyaGF;
@property(nonatomic, strong) NSMutableArray *masGlLVBPahTcRnKC;
@property(nonatomic, strong) NSMutableArray *hfOycNAjKoHJeqClFVMs;
@property(nonatomic, strong) NSArray *nrOAxGySUEbQkHIpzdPTfu;
@property(nonatomic, strong) NSDictionary *audHrSjOsFXPBCaqeEInotGZb;
@property(nonatomic, strong) NSNumber *ibYEpqQzbuxdA;
@property(nonatomic, strong) NSNumber *udvZXexlCFAIwfhEy;
@property(nonatomic, strong) NSDictionary *jgLsrYvUcAzBDeTdZIRX;
@property(nonatomic, strong) NSArray *qfSqtscLNXfGTRyrMxDYKvmU;
@property(nonatomic, strong) NSObject *zrejbqkvGPKDJVRlmpOMou;
@property(nonatomic, strong) NSArray *hxorACKpWUeZljVzBDhf;
@property(nonatomic, strong) NSObject *abNqXSlQngKvOGZyDY;
@property(nonatomic, strong) NSMutableDictionary *gtVYAfytqxeHipawDKszgn;
@property(nonatomic, strong) NSDictionary *pbxfIMTyWbXJvBtPnCEuis;
@property(nonatomic, strong) NSMutableArray *tngxBsqMaoQUkdRpVNybTcDeFGL;
@property(nonatomic, strong) NSNumber *ywVMFyJwqpfRLSiz;
@property(nonatomic, strong) NSNumber *rdvtPjWZCopwiESIfNV;
@property(nonatomic, strong) NSArray *sbzljTFxUOnYJCm;
@property(nonatomic, strong) NSDictionary *qnYHgyDvLxBsjnEaK;
@property(nonatomic, strong) NSObject *vaNZHbokOqBQmgKclCWSr;
@property(nonatomic, strong) NSDictionary *svnKBhDYsaybMJ;
@property(nonatomic, strong) NSArray *chsohizvZcQUGrRyPeTAxIa;
@property(nonatomic, strong) NSMutableArray *wzPKYxctQjZpy;
@property(nonatomic, strong) NSNumber *vtZeRApuVNhKXBMTS;
@property(nonatomic, strong) NSArray *uiaszhfxFMDPLRJrKg;
@property(nonatomic, strong) NSMutableArray *yrKgdMAtInqbifPGNO;
@property(nonatomic, strong) NSDictionary *ecJkVTzrhbCfsNGBpvLH;
@property(nonatomic, strong) NSArray *wkzmfAiGHytPM;
@property(nonatomic, strong) NSArray *ufnUAqYVgDxaKH;
@property(nonatomic, strong) NSObject *voxbBhwJPzjosyMpvidVT;
@property(nonatomic, copy) NSString *wtucwjnLaYyVtWSorfBENOMDhp;
@property(nonatomic, copy) NSString *adxmERgoBiktAZzsWbNK;
@property(nonatomic, strong) NSDictionary *erwCQtaknOGJfmgPZxNYR;
@property(nonatomic, strong) NSNumber *aiKxeUmhVJptTo;
@property(nonatomic, strong) NSMutableArray *ztgLfYKAXyjsVDqrEkHObT;



/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
